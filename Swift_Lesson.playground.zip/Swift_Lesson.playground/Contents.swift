import UIKit

var greeting = "Hello, playground"

var morning : String = "joe mama"

var num : Int = 1

var floater : Float = 2.20

print("morning \(num) " + morning)

var arraynames : [String] = ["Leo","🧌joe🫃😹"]

arraynames.count
arraynames.isEmpty

arraynames.append("hawk tuah")

print(arraynames)

var grades : [String:Int] = ["joe":99,"collon":12, "mama":2]

grades.count

print(grades["joe"]!)


for i in 1...12{
    print(i)
}

for j in 0...arraynames.count - 1{
    
}

func nightgreetings() {
        print("good night")
}


nightgreetings()


func checktemp(temp : Int){
    if (temp <= 32) {
        print("It's freezing mate \(temp)")
    }
}

checktemp(temp: 12)

func gorunbum(miles : Int) -> String{
    
    
    return "bruh"
}

class Name{
    
    var color : String
    
    init(color: String) {
        self.color = color
    }
    
    func sound() {
        print("oi oi oi oi")
    }
    
    
}

var pet = Name(color: "purple")

print(pet.color)

class cat : Name{
    
    var breed : String
    
    init(color: String, breed: String) {
        self.breed = breed
        super.init(color: color)
    }
    
    override func sound(){
        print("Meow Meow")
    }
}

var pompom = cat(color: "gray", breed: "meow meow")

print(pompom.breed)
print(pompom.color)
